package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Student;
import model.Fee;

public class StudentController {

	public List<Student> getAllActiveStudents() {
		List<Student> list = new ArrayList<>();
		String sql = "SELECT * FROM students WHERE status = 'Active'";
		try (Connection conn = DatabaseConnection.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				list.add(new Student(rs.getInt("student_id"), rs.getString("student_name"), rs.getInt("attendance"),
						rs.getDouble("marks"), rs.getString("status")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Fee> getAllFees() {
		List<Fee> list = new ArrayList<>();
		String sql = "SELECT f.student_id, f.subjects_picked, f.total_fees, f.paid_fees FROM fees f "
				+ "JOIN students s ON f.student_id = s.student_id WHERE s.status = 'Active'";
		try (Connection conn = DatabaseConnection.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				list.add(new Fee(rs.getInt("student_id"), rs.getString("subjects_picked"), rs.getDouble("total_fees"),
						rs.getDouble("paid_fees")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Student> searchStudents(String keyword) {
		List<Student> list = new ArrayList<>();
		String sql = "SELECT * FROM students WHERE student_name LIKE ? AND status = 'Active'";
		try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, "%" + keyword + "%");
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					list.add(new Student(rs.getInt("student_id"), rs.getString("student_name"), rs.getInt("attendance"),
							rs.getDouble("marks"), rs.getString("status")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean addStudent(int id, String name, int attendance, double marks, String subjects, double totalFees,
			double paidFees) throws SQLException {
		String insertStudentSQL = "INSERT INTO students (student_id, student_name, attendance, marks, status) VALUES (?, ?, ?, ?, 'Active')";
		String insertFeeSQL = "INSERT INTO fees (student_id, subjects_picked, total_fees, paid_fees) VALUES (?, ?, ?, ?)";

		try (Connection conn = DatabaseConnection.getConnection()) {
			conn.setAutoCommit(false);
			try (PreparedStatement psStudent = conn.prepareStatement(insertStudentSQL);
					PreparedStatement psFee = conn.prepareStatement(insertFeeSQL)) {

				psStudent.setInt(1, id);
				psStudent.setString(2, name);
				psStudent.setInt(3, attendance);
				psStudent.setDouble(4, marks);
				psStudent.executeUpdate();

				psFee.setInt(1, id);
				psFee.setString(2, subjects);
				psFee.setDouble(3, totalFees);
				psFee.setDouble(4, paidFees);
				psFee.executeUpdate();

				conn.commit();
				return true;
			} catch (SQLException e) {
				conn.rollback();
				throw e;
			}
		}
	}

	public boolean updateStudent(int id, String name, int att, double marks, String subjects, double totalFees,
			double paidFees) {
		String updateStudentSQL = "UPDATE students SET student_name = ?, attendance = ?, marks = ? WHERE student_id = ?";
		String updateFeeSQL = "UPDATE fees SET subjects_picked = ?, total_fees = ?, paid_fees = ? WHERE student_id = ?";
		try (Connection conn = DatabaseConnection.getConnection()) {
			conn.setAutoCommit(false);
			try (PreparedStatement psS = conn.prepareStatement(updateStudentSQL);
					PreparedStatement psF = conn.prepareStatement(updateFeeSQL)) {

				psS.setString(1, name);
				psS.setInt(2, att);
				psS.setDouble(3, marks);
				psS.setInt(4, id);
				psS.executeUpdate();

				psF.setString(1, subjects);
				psF.setDouble(2, totalFees);
				psF.setDouble(3, paidFees);
				psF.setInt(4, id);
				psF.executeUpdate();

				conn.commit();
				return true;
			} catch (SQLException e) {
				conn.rollback();
				throw e;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean softDeleteStudent(int id) {
		String sql = "UPDATE students SET status = 'Inactive' WHERE student_id = ?";
		try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			return ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}