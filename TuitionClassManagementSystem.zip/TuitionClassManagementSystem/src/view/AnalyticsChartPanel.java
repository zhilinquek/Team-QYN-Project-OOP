package view;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class AnalyticsChartPanel extends JPanel {
	private Map<String, Integer> gradeDistribution;

	public void setChartData(Map<String, Integer> data) {
		this.gradeDistribution = data;
		repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (gradeDistribution == null || gradeDistribution.isEmpty())
			return;

		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		int width = getWidth();
		int height = getHeight();
		int padding = 30;
		int barWidth = (width - (padding * 2)) / 4 - 10;

		int maxCount = 0;
		for (int count : gradeDistribution.values()) {
			if (count > maxCount)
				maxCount = count;
		}
		if (maxCount == 0)
			maxCount = 1;

		int x = padding + 10;
		String[] levels = { "Excellent", "Good", "Average", "Weak" };
		Color[] colors = { new Color(46, 204, 113), new Color(52, 152, 219), new Color(241, 196, 15),
				new Color(231, 76, 60) };

		for (int i = 0; i < levels.length; i++) {
			String label = levels[i];
			int count = gradeDistribution.getOrDefault(label, 0);

			int barHeight = (int) (((double) count / maxCount) * (height - (padding * 2) - 20));
			int y = height - padding - barHeight;

			g2.setColor(colors[i]);
			g2.fillRect(x, y, barWidth, barHeight);
			g2.setColor(Color.DARK_GRAY);
			g2.drawRect(x, y, barWidth, barHeight);

			g2.setColor(Color.BLACK);
			g2.drawString(label, x + 5, height - 12);
			g2.drawString(String.valueOf(count), x + (barWidth / 2) - 3, y - 5);

			x += barWidth + 10;
		}
	}
}