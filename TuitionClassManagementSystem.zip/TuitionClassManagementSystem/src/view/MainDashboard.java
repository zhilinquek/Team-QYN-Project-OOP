package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import controller.StudentController;
import controller.ReportService;
import model.Student;
import model.Fee;

public class MainDashboard extends JFrame {
	private StudentController controller = new StudentController();
	private ReportService reportService = new ReportService();

	private JTable studentTable, feeTable;
	private DefaultTableModel studentModel, feeModel;
	private AnalyticsChartPanel chartPanel;

	private JTextField txtSearch, txtId, txtName, txtAttendance, txtMarks, txtTotalFee, txtPaidFee;
	private JCheckBox chkBM, chkBI, chkMath, chkSejarah, chkSains;

	private JLabel lblPerformance, lblWarning, lblFeeStatus, lblTotalRevenue;
	private JButton btnSearch, btnClear, btnAdd, btnUpdate, btnDelete, btnEmail, btnPdf;

	private static final double COST_PER_SUBJECT = 120.00;

	public MainDashboard() {
		setTitle("Tuition Center Workspace Dashboard Engine");
		setSize(1250, 780);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout(15, 15));

		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
		topPanel.setBorder(BorderFactory.createEtchedBorder());
		topPanel.add(new JLabel("Search Name:"));
		txtSearch = new JTextField(15);
		btnSearch = new JButton("Search Name");
		btnClear = new JButton("Reset View");
		btnEmail = new JButton("✉ Send Fee Reminders (JavaMail API)");
		btnPdf = new JButton("📄 Export Performance PDF Report");

		topPanel.add(txtSearch);
		topPanel.add(btnSearch);
		topPanel.add(btnClear);
		topPanel.add(btnEmail);
		topPanel.add(btnPdf);
		add(topPanel, BorderLayout.NORTH);

		JPanel centerGridPanel = new JPanel(new GridLayout(3, 1, 0, 15));

		String[] studentHeaders = { "Student ID", "Name", "Attendance (%)", "Marks", "Predicted Performance" };
		studentModel = new DefaultTableModel(studentHeaders, 0);
		studentTable = new JTable(studentModel);
		JPanel pnlStudentTable = new JPanel(new BorderLayout());
		pnlStudentTable.setBorder(BorderFactory.createTitledBorder("Student Information Database Grid"));
		pnlStudentTable.add(new JScrollPane(studentTable), BorderLayout.CENTER);
		centerGridPanel.add(pnlStudentTable);

		String[] feeHeaders = { "Student ID", "Subjects Selected", "Total Cost (RM)", "Paid Cost (RM)",
				"Outstanding Balance (RM)" };
		feeModel = new DefaultTableModel(feeHeaders, 0);
		feeTable = new JTable(feeModel);
		JPanel pnlFeeTable = new JPanel(new BorderLayout());
		pnlFeeTable.setBorder(BorderFactory.createTitledBorder("Tuition Fees Ledger Accounts"));
		pnlFeeTable.add(new JScrollPane(feeTable), BorderLayout.CENTER);
		centerGridPanel.add(pnlFeeTable);

		chartPanel = new AnalyticsChartPanel();
		chartPanel.setBorder(BorderFactory.createTitledBorder("Grade Analytics Graphical Distribution"));
		centerGridPanel.add(chartPanel);
		add(centerGridPanel, BorderLayout.CENTER);

		JPanel eastPanel = new JPanel();
		eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.Y_AXIS));
		eastPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 10, 15));
		eastPanel.setPreferredSize(new Dimension(360, 700));

		JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 6));
		formPanel.setBorder(BorderFactory.createTitledBorder("Student Terminal Profile Form"));
		formPanel.add(new JLabel("Student ID:"));
		txtId = new JTextField();
		formPanel.add(txtId);
		formPanel.add(new JLabel("Student Full Name:"));
		txtName = new JTextField();
		formPanel.add(txtName);
		formPanel.add(new JLabel("Attendance (%):"));
		txtAttendance = new JTextField();
		formPanel.add(txtAttendance);
		formPanel.add(new JLabel("Academic Marks:"));
		txtMarks = new JTextField();
		formPanel.add(txtMarks);
		formPanel.add(new JLabel("Total Fee (RM):"));
		txtTotalFee = new JTextField("0.0");
		txtTotalFee.setEditable(false);
		formPanel.add(txtTotalFee);
		formPanel.add(new JLabel("Current Paid (RM):"));
		txtPaidFee = new JTextField("0.0");
		formPanel.add(txtPaidFee);
		eastPanel.add(formPanel);

		JPanel subjectPickPanel = new JPanel(new GridLayout(2, 3, 5, 5));
		subjectPickPanel.setBorder(BorderFactory.createTitledBorder("Subject Menu Core Selection Matrix"));
		chkBM = new JCheckBox("BM");
		chkBI = new JCheckBox("BI");
		chkMath = new JCheckBox("MATEMATIK");
		chkSejarah = new JCheckBox("SEJARAH");
		chkSains = new JCheckBox("SAINS");
		subjectPickPanel.add(chkBM);
		subjectPickPanel.add(chkBI);
		subjectPickPanel.add(chkMath);
		subjectPickPanel.add(chkSejarah);
		subjectPickPanel.add(chkSains);
		eastPanel.add(subjectPickPanel);

		JPanel insightsPanel = new JPanel(new GridLayout(4, 1, 5, 4));
		insightsPanel.setBorder(BorderFactory.createTitledBorder("Automated Metrics Diagnostics Engine"));
		lblPerformance = new JLabel("Predicted Grade Level: -");
		lblWarning = new JLabel("Attendance Rule Flag: -");
		lblFeeStatus = new JLabel("Outstanding Liability: -");
		lblTotalRevenue = new JLabel("Monthly Center Revenue: RM 0.00");
		insightsPanel.add(lblPerformance);
		insightsPanel.add(lblWarning);
		insightsPanel.add(lblFeeStatus);
		insightsPanel.add(lblTotalRevenue);
		eastPanel.add(insightsPanel);

		JPanel actionPanel = new JPanel(new GridLayout(3, 1, 10, 6));
		btnAdd = new JButton("Register New Student Profile");
		btnUpdate = new JButton("Modify Selection Changes");
		btnDelete = new JButton("Apply Safe Soft Delete");
		actionPanel.add(btnAdd);
		actionPanel.add(btnUpdate);
		actionPanel.add(btnDelete);
		eastPanel.add(actionPanel);
		add(eastPanel, BorderLayout.EAST);

		ActionListener subjectCostEngineListener = e -> calculateMenuFeesLive();
		chkBM.addActionListener(subjectCostEngineListener);
		chkBI.addActionListener(subjectCostEngineListener);
		chkMath.addActionListener(subjectCostEngineListener);
		chkSejarah.addActionListener(subjectCostEngineListener);
		chkSains.addActionListener(subjectCostEngineListener);

		refreshBothTablesAndAnalytics();

		btnClear.addActionListener(e -> {
			txtSearch.setText("");
			refreshBothTablesAndAnalytics();
			clearFields();
		});

		btnSearch.addActionListener(e -> {
			String keyword = txtSearch.getText().trim();
			List<Student> results = controller.searchStudents(keyword);
			studentModel.setRowCount(0);
			for (Student s : results) {
				studentModel.addRow(new Object[] { s.getStudentId(), s.getStudentName(), s.getAttendance(),
						s.getMarks(), s.getPerformanceLevel() });
			}
		});

		btnAdd.addActionListener(e -> {
			// PROACTIVE VALIDATION: Intercepts blank text issues completely to avoid
			// unparsed string format crashes!
			if (txtId.getText().trim().isEmpty() || txtName.getText().trim().isEmpty()
					|| txtAttendance.getText().trim().isEmpty() || txtMarks.getText().trim().isEmpty()
					|| txtPaidFee.getText().trim().isEmpty()) {
				JOptionPane.showMessageDialog(this,
						"Input Required:\nPlease fill out all input fields before executing registration commands.",
						"Empty Fields Notice", JOptionPane.WARNING_MESSAGE);
				return;
			}
			try {
				int id = Integer.parseInt(txtId.getText().trim());
				String name = txtName.getText().trim();
				int att = Integer.parseInt(txtAttendance.getText().trim());
				double marks = Double.parseDouble(txtMarks.getText().trim());
				String subjects = getSelectedSubjectsString();
				double totalFee = Double.parseDouble(txtTotalFee.getText().trim());
				double paidFee = Double.parseDouble(txtPaidFee.getText().trim());

				if (controller.addStudent(id, name, att, marks, subjects, totalFee, paidFee)) {
					JOptionPane.showMessageDialog(this, "Success: Student saved!");
					clearFields();
					refreshBothTablesAndAnalytics();
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(this,
						"Format Error: Please use pure standard numbers for ID, Attendance, and Marks.",
						"Validation Alert", JOptionPane.ERROR_MESSAGE);
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, "System Alert: Verification key error or constraint issue.");
			}
		});

		btnUpdate.addActionListener(e -> {
			if (txtId.getText().trim().isEmpty() || txtName.getText().trim().isEmpty()
					|| txtAttendance.getText().trim().isEmpty() || txtMarks.getText().trim().isEmpty()
					|| txtPaidFee.getText().trim().isEmpty()) {
				JOptionPane.showMessageDialog(this,
						"Selection Required:\nEnsure text fields are completely loaded before modifying variables.",
						"Empty Fields Notice", JOptionPane.WARNING_MESSAGE);
				return;
			}
			try {
				int id = Integer.parseInt(txtId.getText().trim());
				String name = txtName.getText().trim();
				int att = Integer.parseInt(txtAttendance.getText().trim());
				double marks = Double.parseDouble(txtMarks.getText().trim());
				String subjects = getSelectedSubjectsString();
				double totalFee = Double.parseDouble(txtTotalFee.getText().trim());
				double paidFee = Double.parseDouble(txtPaidFee.getText().trim());

				if (controller.updateStudent(id, name, att, marks, subjects, totalFee, paidFee)) {
					JOptionPane.showMessageDialog(this, "Success: Database values synchronized!");
					refreshBothTablesAndAnalytics();
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(this,
						"Format Error: Please verify that input text properties use valid numbers.", "Validation Alert",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		btnDelete.addActionListener(e -> {
			if (txtId.getText().trim().isEmpty()) {
				JOptionPane.showMessageDialog(this,
						"Action Required:\nSelect a student row tracking profile to deactivate.", "Row Request Missing",
						JOptionPane.INFORMATION_MESSAGE);
				return;
			}
			int id = Integer.parseInt(txtId.getText().trim());
			if (controller.softDeleteStudent(id)) {
				JOptionPane.showMessageDialog(this, "Profile status updated to 'Inactive' successfully.");
				clearFields();
				refreshBothTablesAndAnalytics();
			}
		});

		btnPdf.addActionListener(e -> {
			String result = reportService.generatePdfReport();
			if (result.equals("SUCCESS")) {
				JOptionPane.showMessageDialog(this,
						"PDF Generated Successfully!\nSaved inside root path as: Tuition_Center_Performance_Report.pdf\nRight-click your root workspace and hit 'Refresh' to see the file layout.",
						"PDF Print Success", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(this, "PDF Compiling Issue: " + result, "Engine Error",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		btnEmail.addActionListener(e -> {
			setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			String result = reportService.sendFeeReminders();
			setCursor(Cursor.getDefaultCursor());
			JOptionPane.showMessageDialog(this, result, "JavaMail API Subsystem Diagnostic Console",
					JOptionPane.INFORMATION_MESSAGE);
		});

		studentTable.getSelectionModel().addListSelectionListener(e -> {
			int selectedRow = studentTable.getSelectedRow();
			if (selectedRow != -1) {
				int id = (int) studentModel.getValueAt(selectedRow, 0);
				txtId.setText(String.valueOf(id));
				txtName.setText((String) studentModel.getValueAt(selectedRow, 1));
				txtAttendance.setText(String.valueOf(studentModel.getValueAt(selectedRow, 2)));
				txtMarks.setText(String.valueOf(studentModel.getValueAt(selectedRow, 3)));

				Student temp = new Student(id, txtName.getText(), Integer.parseInt(txtAttendance.getText()),
						Double.parseDouble(txtMarks.getText()), "Active");
				lblPerformance.setText("Predicted Grade Level: " + temp.getPerformanceLevel());
				lblWarning.setText("Attendance Rule Flag: " + temp.getAttendanceWarning());

				for (int i = 0; i < feeTable.getRowCount(); i++) {
					if ((int) feeModel.getValueAt(i, 0) == id) {
						feeTable.setRowSelectionInterval(i, i);
						setSelectedCheckboxesFromString(feeModel.getValueAt(i, 1).toString());
						txtTotalFee.setText(feeModel.getValueAt(i, 2).toString());
						txtPaidFee.setText(feeModel.getValueAt(i, 3).toString());
						lblFeeStatus.setText(
								String.format("Outstanding Liability: RM %.2f", (double) feeModel.getValueAt(i, 4)));
						break;
					}
				}
			}
		});
	}

	private void calculateMenuFeesLive() {
		int count = 0;
		if (chkBM.isSelected())
			count++;
		if (chkBI.isSelected())
			count++;
		if (chkMath.isSelected())
			count++;
		if (chkSejarah.isSelected())
			count++;
		if (chkSains.isSelected())
			count++;
		txtTotalFee.setText(String.format("%.2f", count * COST_PER_SUBJECT));
	}

	private String getSelectedSubjectsString() {
		List<String> list = new ArrayList<>();
		if (chkBM.isSelected())
			list.add("BM");
		if (chkBI.isSelected())
			list.add("BI");
		if (chkMath.isSelected())
			list.add("MATEMATIK");
		if (chkSejarah.isSelected())
			list.add("SEJARAH");
		if (chkSains.isSelected())
			list.add("SAINS");
		return String.join(", ", list);
	}

	private void setSelectedCheckboxesFromString(String subjectsStr) {
		chkBM.setSelected(subjectsStr.contains("BM"));
		chkBI.setSelected(subjectsStr.contains("BI"));
		chkMath.setSelected(subjectsStr.contains("MATEMATIK"));
		chkSejarah.setSelected(subjectsStr.contains("SEJARAH"));
		chkSains.setSelected(subjectsStr.contains("SAINS"));
	}

	private void refreshBothTablesAndAnalytics() {
		studentModel.setRowCount(0);
		feeModel.setRowCount(0);
		List<Student> students = controller.getAllActiveStudents();
		List<Fee> fees = controller.getAllFees();

		Map<String, Integer> distributions = new HashMap<>();
		distributions.put("Excellent", 0);
		distributions.put("Good", 0);
		distributions.put("Average", 0);
		distributions.put("Weak", 0);
		double totalMonthlyIncome = 0;

		for (Student s : students) {
			studentModel.addRow(new Object[] { s.getStudentId(), s.getStudentName(), s.getAttendance(), s.getMarks(),
					s.getPerformanceLevel() });
			String performance = s.getPerformanceLevel();
			distributions.put(performance, distributions.get(performance) + 1);
		}
		for (Fee f : fees) {
			feeModel.addRow(new Object[] { f.getStudentId(), f.getSubjectsPicked(), f.getTotalFees(), f.getPaidFees(),
					f.calculateBalance() });
			totalMonthlyIncome += f.getPaidFees();
		}
		chartPanel.setChartData(distributions);
		lblTotalRevenue.setText(String.format("Monthly Center Revenue: RM %.2f", totalMonthlyIncome));
	}

	private void clearFields() {
		txtId.setText("");
		txtName.setText("");
		txtAttendance.setText("");
		txtMarks.setText("");
		txtTotalFee.setText("0.0");
		txtPaidFee.setText("0.0");
		chkBM.setSelected(false);
		chkBI.setSelected(false);
		chkMath.setSelected(false);
		chkSejarah.setSelected(false);
		chkSains.setSelected(false);
		lblPerformance.setText("Predicted Grade Level: -");
		lblWarning.setText("Attendance Rule Flag: -");
		lblFeeStatus.setText("Outstanding Liability: -");
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new MainDashboard().setVisible(true));
	}
}