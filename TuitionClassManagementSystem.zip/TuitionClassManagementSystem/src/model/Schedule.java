package model;

public class Schedule {
	private int scheduleId;
	private String classDay;
	private String classTime;
	private String subject;

	public Schedule(int scheduleId, String classDay, String classTime, String subject) {
		this.scheduleId = scheduleId;
		this.classDay = classDay;
		this.classTime = classTime;
		this.subject = subject;
	}

	public int getScheduleId() {
		return scheduleId;
	}

	public String getClassDay() {
		return classDay;
	}

	public String getClassTime() {
		return classTime;
	}

	public String getSubject() {
		return subject;
	}
}