package model;

public class Fee {
	private int studentId;
	private String subjectsPicked;
	private double totalFees;
	private double paidFees;

	public Fee(int studentId, String subjectsPicked, double totalFees, double paidFees) {
		this.studentId = studentId;
		this.subjectsPicked = subjectsPicked;
		this.totalFees = totalFees;
		this.paidFees = paidFees;
	}

	public int getStudentId() {
		return studentId;
	}

	public String getSubjectsPicked() {
		return subjectsPicked;
	}

	public double getTotalFees() {
		return totalFees;
	}

	public double getPaidFees() {
		return paidFees;
	}

	public double calculateBalance() {
		return totalFees - paidFees;
	}
}
