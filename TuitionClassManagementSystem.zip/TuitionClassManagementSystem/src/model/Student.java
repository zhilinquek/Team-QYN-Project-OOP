package model;

public class Student {
	private int studentId;
	private String studentName;
	private int attendance;
	private double marks;
	private String status;

	public Student(int studentId, String studentName, int attendance, double marks, String status) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.attendance = attendance;
		this.marks = marks;
		this.status = status;
	}

	public int getStudentId() {
		return studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public int getAttendance() {
		return attendance;
	}

	public double getMarks() {
		return marks;
	}

	public String getStatus() {
		return status;
	}

	public String getPerformanceLevel() {
		if (marks >= 80)
			return "Excellent";
		if (marks >= 60)
			return "Good";
		if (marks >= 40)
			return "Average";
		return "Weak";
	}

	public String getAttendanceWarning() {
		return (attendance < 75) ? "Warning: Low Attendance!" : "Attendance OK";
	}
}