package model;

public class Tutor {
	private int tutorId;
	private String tutorName;
	private String subject;

	public Tutor(int tutorId, String tutorName, String subject) {
		this.tutorId = tutorId;
		this.tutorName = tutorName;
		this.subject = subject;
	}

	public int getTutorId() {
		return tutorId;
	}

	public String getTutorName() {
		return tutorName;
	}

	public String getSubject() {
		return subject;
	}
}